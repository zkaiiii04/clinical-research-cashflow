Cash Flow Dashboard v0.9 - start here (rebuilt 11 Oct 2026, queryTable9 repair fixed)

Workbook: Clinical_Research_Cash_Flow_SharePoint_PQ_Ready_v0.9_working.xlsm
SHA-256:  56d23584b7b87e31b0d2ce4e414a7923a77643b8226c3ecd58cb6ceacda1f6bd
Check it on Windows (PowerShell):  Get-FileHash .\Clinical_Research_Cash_Flow_SharePoint_PQ_Ready_v0.9_working.xlsm

1. Open the workbook in desktop Excel for Windows only. Not Excel on a phone, tablet or the web.
   If Excel says it found a problem and offers to repair the file, click No and report it. Do not save a repaired copy.
2. Open docs\v0.9_Install_and_User_Guide.docx and follow section 3 (install the macros).
3. Then work through tests\UAT_test_script.md (15 acceptance tests).

Do not open or save the workbook in LibreOffice, Google Sheets, Excel for the web or Excel mobile.
The manpower table keeps its v0.8 name, qManpower_SelectedTest (sheet PQManpower_SelectedTest).
The stable v0.8 workbook is not included and has not been changed.
