Cash Flow Dashboard v0.9 - start here (repackaged 12 Oct 2026, spec v1.0.7)

No workbook in this package (for now). Use your own v0.9_working copy, the one with the
project selector in row 5 (E5:G5). The macros here read the selector from row 5.

What is in it
- vba\modTimeline.bas, vba\modStore.bas, vba\modSetup.bas, vba\ThisWorkbook_code.txt: the current macros
  (tested by the user in desktop Excel on 12 Oct 2026: rows 2-19 collapse, Remarks column).
- docs\v0.9_Install_and_User_Guide.docx: install and usage guide.
- tests\UAT_test_script.md: 18 acceptance tests.
- specs, docs, handovers: design and project records.

Update the macros in your copy
1. Alt+F11 > right-click modTimeline > Remove modTimeline (No to export). Do the same for modStore.
2. File > Import File > vba\modTimeline.bas, then vba\modStore.bas (and modSetup.bas if you rerun setup).
3. Debug > Compile VBAProject, save (keep .xlsm), then click Load Project.

Use the .bas files from this zip, not GitHub 'Raw' (they need Windows line endings).
Open the workbook in desktop Excel for Windows only, never LibreOffice, Google Sheets, Excel for the web or mobile.
The stable v0.8 workbook is not included and has not been changed.
