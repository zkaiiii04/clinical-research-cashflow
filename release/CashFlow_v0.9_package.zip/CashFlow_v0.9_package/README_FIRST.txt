Cash Flow Dashboard v0.9 - start here

1. Open docs\v0.9_Install_and_User_Guide.docx and follow section 3 (install the macros).
2. Then work through tests\UAT_test_script.md (15 acceptance tests).

Use desktop Excel for Windows. Do not open or save the workbook in LibreOffice, Google Sheets or Excel for the web.
The stable v0.8 workbook is not included and has not been changed.
