Cash Flow Dashboard v0.9 - start here (rebuilt 11 Oct 2026: project end-date fix, spec v1.0.3)

Workbook: Clinical_Research_Cash_Flow_SharePoint_PQ_Ready_v0.9_working.xlsm
SHA-256:  0e95e83737e3c6c82f5f55a3becaf53b885820be6cc3864b1eb85cc58b133b5a
Check it on Windows (PowerShell):  Get-FileHash .\Clinical_Research_Cash_Flow_SharePoint_PQ_Ready_v0.9_working.xlsm

What changed in this rebuild
- The timeline and the Project Start / Project End cells (C7/C8) now use the project dates from
  qProjects_SelectedTest (IREx), not the SOA budget LOA dates. Load Project warns when the two differ.

If you already installed the macros in your own copy (upgrade instead of starting again)
1. Alt+F11 > right-click modTimeline > Remove modTimeline (No to export) > File > Import File > vba\modTimeline.bas.
2. On Main_Dashboard, unprotect the sheet (Review > Unprotect Sheet, no password) and paste these formulas:
C7: =IFERROR(1/(1/INDEX(qProjects_SelectedTest[Project Start],MATCH("Main",qProjects_SelectedTest[IO Code Type],0))),IFERROR(INDEX(tblSelectedProjectMapping[Project Start],MATCH("Yes",tblSelectedProjectMapping[Main IO],0)),""))
C8: =IFERROR(1/(1/INDEX(qProjects_SelectedTest[Project End],MATCH("Main",qProjects_SelectedTest[IO Code Type],0))),IFERROR(INDEX(tblSelectedProjectMapping[Project End],MATCH("Yes",tblSelectedProjectMapping[Main IO],0)),""))
3. Debug > Compile VBAProject, save, then click Load Project.

Starting fresh with this workbook
1. Open the workbook in desktop Excel for Windows only. Not Excel on a phone, tablet or the web.
   If Excel says it found a problem and offers to repair the file, click No and report it. Do not save a repaired copy.
2. Open docs\v0.9_Install_and_User_Guide.docx and follow section 3 (install the macros).
3. Then work through tests\UAT_test_script.md (16 acceptance tests; test 16 is tDCS project dates).

Do not open or save the workbook in LibreOffice, Google Sheets, Excel for the web or Excel mobile.
The manpower table keeps its v0.8 name, qManpower_SelectedTest (sheet PQManpower_SelectedTest).
The stable v0.8 workbook is not included and has not been changed.
